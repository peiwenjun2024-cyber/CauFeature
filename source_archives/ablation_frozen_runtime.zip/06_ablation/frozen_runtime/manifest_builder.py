#!/usr/bin/env python3
import csv, hashlib, json
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path("/root/autodl-tmp/fast30_final")
DATASET_DIR = ROOT / "code_revised_20260910" / "dataset"
MANIFEST = ROOT / "manifest" / "split_manifest.jsonl"
SPLIT_ROOT = ROOT / "splits"
SEEDS = [f"S{i:02d}" for i in range(1, 31)]
SEPARATORS = [",", ";", "\t"]

def detect_separator(path):
    candidates = []
    for sep in SEPARATORS:
        try:
            with open(path, encoding="utf-8", errors="ignore") as f:
                rows = list(csv.reader(f, delimiter=sep))[:20]
            widths = [len(r) for r in rows if r]
            if widths:
                candidates.append((max(widths), sum(widths) / len(widths), sep))
        except Exception:
            pass
    return max(candidates, key=lambda x: (x[0], x[1]))[2]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_split(dataset, sid, n, seed):
    out = SPLIT_ROOT / dataset.replace(".csv", "") / f"{sid}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    tr, te = train_test_split(range(n), test_size=.2, random_state=seed)
    tr, va = train_test_split(tr, test_size=.25, random_state=seed)
    rows = []
    for part, idx in [("train", tr), ("validation", va), ("test", te)]:
        rows.extend({"row_index": int(i), "partition": part} for i in idx)
    pd.DataFrame(rows).to_csv(out, index=False)
    return out

files = sorted(DATASET_DIR.glob("*.csv"))
# Production fast30 uses the fixed 10% DiabetesHealth sample, never both versions.
if (DATASET_DIR / "DiabetesHealth_sample10.csv").exists():
    files = [f for f in files if f.name != "DiabetesHealth.csv"]

with MANIFEST.open("w") as w:
    for f in files:
        sep = detect_separator(f)
        df = pd.read_csv(f, sep=sep)
        for i, sid in enumerate(SEEDS, 1):
            sf = make_split(f.name, sid, len(df), i)
            obj = {
                "dataset": f.name, "separator": sep, "n_samples": len(df),
                "n_features": len(df.columns) - 1, "sha256": sha(f),
                "split_seed_id": sid, "split_seed": i,
                "split_file": str(sf), "split_hash": sha(sf),
            }
            w.write(json.dumps(obj) + "\n")
print(MANIFEST)

#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
import pandas as pd

from runtime_provenance import METHOD_VERSION, DEFAULT_OUTPUT_NAME

ROOT = Path(__file__).resolve().parents[1]
RESULT_ROOT = ROOT / 'results' / DEFAULT_OUTPUT_NAME
MANIFEST = ROOT / 'manifest' / 'split_manifest.jsonl'
DATA_DIR = ROOT / 'code_revised_20260910' / 'dataset'
SEEDS = [f'S{i:02d}' for i in range(1, 31)]
TIE_TOL = 1e-12


def load_manifest():
    with MANIFEST.open() as f:
        return [json.loads(x) for x in f if x.strip()]


def mean_std(values):
    vals = np.asarray(values, dtype=float)
    if len(vals) == 0:
        return '-'
    # Match descriptive monitoring style: population std across completed seeds.
    return f'{vals.mean():+.2f}±{vals.std(ddof=0):.2f}'


def reliability_for_seed(seed_dir):
    p = seed_dir / 'p1_cache.json'
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text())
        rr = d.get('reliability_records', {})
        vals = [
            float(v['reliability']) for v in rr.values()
            if isinstance(v, dict) and 'reliability' in v
        ]
        return float(np.mean(vals)) if vals else None
    except Exception:
        return None


def active_runs():
    active = []
    if not RESULT_ROOT.exists():
        return active
    for status in RESULT_ROOT.glob('*/S*/running_status.json'):
        try:
            d = json.loads(status.read_text())
            if str(d.get('status', '')).lower() == 'running':
                active.append((d.get('dataset', '?'), d.get('seed', '?'), d.get('stage', '?')))
        except Exception:
            pass
    return sorted(active)


def main():
    rows = load_manifest()
    datasets = sorted({r['dataset'] for r in rows})
    first_manifest = {ds: next(r for r in rows if r['dataset'] == ds) for ds in datasets}

    print('=' * 154)
    print(f'{METHOD_VERSION} MONITOR')
    print('=' * 154)
    active = active_runs()
    if active:
        print('ACTIVE: ' + ' | '.join(f'{d} {s} [{st}]' for d, s, st in active))
    else:
        print('ACTIVE: -')
    print('-' * 154)
    print(
        f"{'DATASET':<25} {'D(features)':>11} {'N(samples)':>11} {'DONE/30':>9} "
        f"{'dAcc(mean±std)':>19} {'dF1(mean±std)':>19} {'Reliability(mean±std)':>24} "
        f"{'FULLFEATURE(Win/Tie/Loss)':>27} {'SelectedFeatures(mean±std)':>27}"
    )
    print('-' * 154)

    total_done = 0
    total_failed = 0

    for ds in datasets:
        m = first_manifest[ds]
        csv_path = DATA_DIR / ds
        df = pd.read_csv(csv_path, sep=m.get('separator', ','))
        n_samples = len(df)
        d_features = len(df.columns) - 1

        stem = Path(ds).stem
        dacc, df1, reliab, dims = [], [], [], []
        wins = ties = losses = 0
        done = 0
        failed = 0

        for sid in SEEDS:
            sd = RESULT_ROOT / stem / sid
            rec = sd / 'record.json'
            fail = sd / 'failed.json'
            if fail.exists() and not rec.exists():
                failed += 1
            if not rec.exists():
                continue
            try:
                r = json.loads(rec.read_text())
                if str(r.get('status', '')).lower() not in {'complete','completed','success','done'}:
                    continue
                done += 1

                delta = r.get('paired_delta', {})
                da = float(delta.get('accuracy_pp', np.nan))
                dfv = float(delta.get('f1_macro_pp', np.nan))
                if np.isfinite(da):
                    dacc.append(da)
                    if da > TIE_TOL:
                        wins += 1
                    elif da < -TIE_TOL:
                        losses += 1
                    else:
                        ties += 1
                if np.isfinite(dfv):
                    df1.append(dfv)

                sel = r.get('selection', {})
                dim = sel.get('final_dimension')
                if dim is not None:
                    dims.append(float(dim))

                rv = reliability_for_seed(sd)
                if rv is not None and np.isfinite(rv):
                    reliab.append(rv)
            except Exception:
                continue

        total_done += done
        total_failed += failed
        rel_text = mean_std(reliab)
        # Reliability is a probability-like quantity; show 4 decimals for usefulness.
        if reliab:
            arr = np.asarray(reliab, float)
            rel_text = f'{arr.mean():.4f}±{arr.std(ddof=0):.4f}'

        print(
            f'{stem:<25} {d_features:>11d} {n_samples:>11d} {f"{done}/30":>9} '
            f'{mean_std(dacc):>19} {mean_std(df1):>19} {rel_text:>24} '
            f'{f"{wins}/{ties}/{losses}":>27} {mean_std(dims):>27}'
        )

    print('-' * 154)
    print(f'TOTAL FINAL: {total_done}/450    FAILED: {total_failed}')
    print('Definitions: dAcc/dF1 are selected minus paired full-feature baseline, in percentage points.')
    print('Reliability: mean feature reliability within each seed, then mean±std across completed seeds.')
    print('FULLFEATURE Win/Tie/Loss: sign of paired dAcc with exact-tie tolerance 1e-12.')
    print('=' * 154)


if __name__ == '__main__':
    main()
